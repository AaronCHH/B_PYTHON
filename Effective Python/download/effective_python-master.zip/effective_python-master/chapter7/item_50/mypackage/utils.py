__all__ = ['simulate_collision']


def _dot_product(a, b):
    pass


def simulate_collision(a, b):
    pass
