from .mypackage import *


a = Projectile(1.5, 3)
b = Projectile(4, 1.7)

simulate_collision(a, b)
