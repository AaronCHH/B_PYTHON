try:
    pwd = input('請輸入密碼')
except:
    print('發生錯誤')