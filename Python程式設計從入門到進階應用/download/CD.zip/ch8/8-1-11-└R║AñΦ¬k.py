class Say():
    @staticmethod
    def hello():
        print('Hello')
Say.hello()
