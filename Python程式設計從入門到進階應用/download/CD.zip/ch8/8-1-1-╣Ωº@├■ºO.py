class Animal():
    def __init__(self, name):
        self.name = name
a = Animal('動物')
print(a.name)

