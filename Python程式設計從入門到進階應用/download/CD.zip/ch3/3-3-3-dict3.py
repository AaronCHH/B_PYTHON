lang1={'你好':'Hello'}
lang2={'學生':'Student'}
lang1.update(lang2)
print(lang1)
lang1={'早安':'Good Morning','你好':'Hello'}
lang2={'你好':'Hi'}
lang1.update(lang2)
print(lang1)

