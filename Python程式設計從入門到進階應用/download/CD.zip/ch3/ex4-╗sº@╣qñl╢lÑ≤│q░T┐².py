mail = dict()
name = input('請輸入姓名？')
email = input('請輸入電子郵件？')
mail[name]=email
name = input('請輸入姓名？')
email = input('請輸入電子郵件？')
mail[name]=email
name = input('請輸入姓名？')
email = input('請輸入電子郵件？')
mail[name]=email
name = input('請輸入要查詢電子郵件的姓名？')
print(mail[name])

