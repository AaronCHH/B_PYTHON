shoplist1 = ['牛奶', '蛋', '咖啡豆']
shoplist2 = ['西瓜', '鳳梨']
shoplist_all = shoplist1 + shoplist2
print(shoplist_all)
