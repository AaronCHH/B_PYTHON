星期 = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
月份 = ['January', 'February', 'March', 'April', 'May', 'June', \
      'July', 'August', 'September', 'October', 'November', 'December']
dic = {'week':星期, 'month':月份}
print(dic['month'])
print(dic['month'][7])
