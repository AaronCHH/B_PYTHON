a=1
print(a,id(a))
a='Python'
print(a,id(a))
