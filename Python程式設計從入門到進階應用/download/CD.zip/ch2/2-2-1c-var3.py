x = 1
y = x
print(id(x), id(y))
print(x, y)