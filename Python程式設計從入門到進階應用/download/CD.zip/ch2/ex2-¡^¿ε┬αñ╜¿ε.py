f = int(input('請輸入幾尺？'))
i = int(input('請輸入幾吋？'))
ans = (f*12+i)*2.54
print('轉換成', ans,'公分')