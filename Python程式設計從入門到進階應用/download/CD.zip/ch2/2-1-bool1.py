print(bool(1))
print(bool(0))
print(bool(()))