b = True
print(b, type(b))
num = 20
print(num, type(num))
pi = 3.14
print(pi, type(pi))
s = "Hello"
print(s, type(s))
