c = float(input('請輸入攝氏溫度？'))
f = c * 9 / 5 +32
print('華氏溫度為', f)
