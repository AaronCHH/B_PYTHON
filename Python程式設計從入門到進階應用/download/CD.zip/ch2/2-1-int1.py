print(int(100))
print(int(3.14))
print(int('100',2))