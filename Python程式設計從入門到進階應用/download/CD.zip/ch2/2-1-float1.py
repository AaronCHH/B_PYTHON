print(float(1))
print(float(3.14))
print(float('3.1415'))