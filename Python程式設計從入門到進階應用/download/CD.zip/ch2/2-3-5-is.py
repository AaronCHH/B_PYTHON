x = [1,2,3]
y = [1,2,3]
print(id(x),id(y))
print(x is y)
print(x == y)
