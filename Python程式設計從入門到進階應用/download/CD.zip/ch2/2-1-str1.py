s= str('Python')
s[0]='Q'
