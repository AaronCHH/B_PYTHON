fir = int(input('請輸入第一次期中考成績？'))
sec = int(input('請輸入第二次期中考成績？'))
final = int(input('請輸入期末考成績？'))
sum = fir + sec + final
avg = sum/3
print('總分為', sum, '平均為', avg)