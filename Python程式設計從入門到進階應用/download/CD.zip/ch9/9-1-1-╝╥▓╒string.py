import string
print('ascii_letters為', string.ascii_letters)
print('ascii_lowercase為', string.ascii_lowercase)
print('ascii_uppercase為', string.ascii_uppercase)
print('digits為', string.digits)
print('hexdigits為', string.hexdigits)
print('octdigits為', string.octdigits)
print('punctuation為', string.punctuation)
print("printable.encode('ascii')為", string.printable.encode('ascii'))
print("whitespace.encode('ascii')為", string.whitespace.encode('ascii'))


