mbytes=bytes(range(0,32))
print(mbytes)
mbytearray=bytearray(range(0,32))
print(mbytearray)