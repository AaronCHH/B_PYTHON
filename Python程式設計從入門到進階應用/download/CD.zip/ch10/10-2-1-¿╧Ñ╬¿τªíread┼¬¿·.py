fin = open('poem.txt','rt',encoding='utf-8')
s=fin.read()
print(s)
fin.close()
