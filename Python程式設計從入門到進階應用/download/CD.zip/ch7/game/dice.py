from random import choice
def dice():
    return choice(range(1,7,1))