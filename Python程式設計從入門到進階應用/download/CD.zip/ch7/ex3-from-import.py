from exlotto import lotto
nums = lotto(48, 6)
snums = sorted(nums)
print(snums)