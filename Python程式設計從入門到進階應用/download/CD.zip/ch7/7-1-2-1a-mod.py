import guess
computer = guess.figure_guess()
print(computer)