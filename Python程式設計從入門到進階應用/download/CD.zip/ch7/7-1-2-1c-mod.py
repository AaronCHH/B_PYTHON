import guess as gs
computer = gs.figure_guess()
print(computer)