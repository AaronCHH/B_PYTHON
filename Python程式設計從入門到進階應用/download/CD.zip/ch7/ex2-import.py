import exlotto
nums = exlotto.lotto(48, 6)
snums = sorted(nums)
print(snums)