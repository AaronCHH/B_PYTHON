from prize import exlotto, exreciept
nums = exlotto.lotto(48, 6)
snums = sorted(nums)
print(snums)
s = exreciept.reciept()
print(s)