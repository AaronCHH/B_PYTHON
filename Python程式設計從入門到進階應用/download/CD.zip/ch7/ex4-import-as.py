import exlotto as lot
nums = lot.lotto(48, 6)
snums = sorted(nums)
print(snums)