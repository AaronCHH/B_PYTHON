from game import dice, poker
for i in range(2):
    print(dice.dice())
    print(poker.poker())