from guess import figure_guess
computer = figure_guess()
print(computer)