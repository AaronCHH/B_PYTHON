import random
status = ['剪刀', '石頭', '布']
def figure_guess():
    return random.choice(status)