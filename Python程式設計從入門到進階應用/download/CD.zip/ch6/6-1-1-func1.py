def hi():
    print('hi')
hi()
def min(a,b):
    if a > b:
        return b
    else:
        return a
print(min(2,4))