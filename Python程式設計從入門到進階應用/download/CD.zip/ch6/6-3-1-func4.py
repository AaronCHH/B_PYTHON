def f(s, count=1):
    print(s * count)
f('Hi')
f('Hi',3)
