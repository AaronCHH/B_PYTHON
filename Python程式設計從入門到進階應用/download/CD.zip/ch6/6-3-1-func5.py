def func(x, y, z=9):
    print("x=" , x , "y=" , y , "z=" , z)
func(1, 2)
func(1, 2, 3)
func(x=3, y=4)
func(y=5, x=6)
#func(x=3, z=6)
