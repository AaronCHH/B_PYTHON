def area(x,y):
    return x*y
a = int(input('請輸入長度？'))
b = int(input('請輸入寬度？'))
ans = area(a, b)
print('長方形面積為', ans)

