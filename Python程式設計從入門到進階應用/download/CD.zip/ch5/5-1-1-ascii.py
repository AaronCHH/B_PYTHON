s = int(input('請輸入ASCII的啟始值？'))
e = int(input('請輸入ASCII的終止值？'))
for i in range(s, e):
    print(chr(i))