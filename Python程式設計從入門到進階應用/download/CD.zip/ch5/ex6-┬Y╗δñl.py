import random
while True:
    dice = random.randint(1,6)
    print(dice)
    if dice == 6:
        break