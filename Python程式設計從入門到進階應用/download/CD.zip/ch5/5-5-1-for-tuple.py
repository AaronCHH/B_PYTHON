t = tuple('Tuple')
for i in t:
    print(i)
for i in range(0,len(t)):
    print(t[i])