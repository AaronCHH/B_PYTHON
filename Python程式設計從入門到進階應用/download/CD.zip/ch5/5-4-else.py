for i in range(1,6):
    print(i)
    if i == 6:
        break
else:
    print('for迴圈正常結束')

i = 1
while (i<6):
    print(i)
    if i == 6:
        break
    i += 1
else:
    print('while迴圈正常結束')