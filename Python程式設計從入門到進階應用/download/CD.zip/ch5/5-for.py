for i in range(1000):
    print('Hello')
for i in range(5):
    print(i)
for i in range(2,6):
    print(i)
for i in range(2,10,2):
    print(i)
for i in range(100,90,-3):
    print(i)
