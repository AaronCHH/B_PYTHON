word = 'elephant'
letters = {letter for letter in word}
for i in letters:
    print(i)