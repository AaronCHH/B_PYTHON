for i in range(1,1001):
    if ((i%2 != 0) and (i%3 != 0)): 
        print(i)
