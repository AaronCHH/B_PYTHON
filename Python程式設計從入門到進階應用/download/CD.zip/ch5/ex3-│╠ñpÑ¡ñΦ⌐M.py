sum = 0
i = 0
while sum < 1000:
    i += 1
    sum += i*i   
print('最小的n值為', i)
