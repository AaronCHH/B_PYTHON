a = []
a.append(1)
a.append(2)
a.append(3)
a.append(4)
a.append(5)
print(a)
a = []
for i in range(1,6):
    a.append(i)
print(a)
a = [x for x in range(1,6)]
print(a)