n = int(input('請輸入n值？'))
sum = 0;
for i in range(1,n+1):
    sum = sum + i*i;
print(sum)
