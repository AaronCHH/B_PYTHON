import os
os.system('dir')
print(os.getenv('COMPUTERNAME'))
print(os.getenv('HOMEDRIVE'))
print(os.getenv('HOMEPATH'))
print(os.getenv('USERNAME'))
