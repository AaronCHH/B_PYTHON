from collections import Counter
a = Counter(a=2, b=3)
b = Counter(b=2, c=1)
print(a + b)
print(a - b)
print(a & b)
print(a | b)