import itertools
s = itertools.chain('Py','thon')
print(list(s))