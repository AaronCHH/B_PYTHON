eye = float(input('請輸入眼睛度數？'))
if eye < 0.9:
    print('近視')
else:
    print('視力正常')

