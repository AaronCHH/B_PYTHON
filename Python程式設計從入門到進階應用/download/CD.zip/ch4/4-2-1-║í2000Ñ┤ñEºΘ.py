cost = int(input('請輸入購買金額？'))
if cost >= 2000:
    print(cost * 0.9)
else:
    print(cost)
