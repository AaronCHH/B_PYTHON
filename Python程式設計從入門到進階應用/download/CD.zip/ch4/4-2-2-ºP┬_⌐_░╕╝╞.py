num = int(input('請輸入一個整數？'))
if num%2:
    print(num, '為奇數')
else:
    print(num, '為偶數')
