score = int(input('請輸入一個成績？'))
if score >= 80:
    print('非常好')
elif score >= 60:
    print('不錯喔')
else:
    print('要加油')

