score = int(input('請輸入一個成績？'))
if score >= 60:
    print('很好，請繼續保持下去')

