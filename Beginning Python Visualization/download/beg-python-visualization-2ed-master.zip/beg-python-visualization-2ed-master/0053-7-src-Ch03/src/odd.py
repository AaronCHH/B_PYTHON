class Odd:
    def __init__(self, s=[]):
        self.sequence=s
    def odd(self):
        return self.sequence[::2]