a, b = 2, 3
print(a, b)
a, b = b, a
print(a, b)
