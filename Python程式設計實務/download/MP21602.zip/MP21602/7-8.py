# 7-8.py (Python 3 version)

import random
while True:
    x = random.randint(1,6)
    print(x)
    if x == 6 : break
