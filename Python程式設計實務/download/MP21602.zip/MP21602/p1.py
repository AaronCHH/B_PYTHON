print "Hello"

