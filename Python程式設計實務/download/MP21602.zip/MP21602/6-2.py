# 程式 6-2.py (Python 3 version)
from my_module import draw_bar

draw_bar.draw(10, "$")
draw_bar.draw(6, "#")
draw_bar.draw(15)
