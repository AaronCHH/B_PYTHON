# draw_bar.py (Python 3 version)
def draw(n, symbol="*"):
    for i in range(1, n+1):
        print(symbol,end="")
    print()
