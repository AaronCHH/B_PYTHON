age = input("Please input your age:")
if age > 15:
  print("You are too young")
