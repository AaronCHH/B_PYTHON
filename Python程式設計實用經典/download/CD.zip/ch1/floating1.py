#filename:floating1.py
#function: show how to use float

floating=7//5
print (floating)

quotient = 7 / 3
print(quotient)

remainder = 7 % 4
print (remainder)

#output
#1
#2.3333333333333335
#3
