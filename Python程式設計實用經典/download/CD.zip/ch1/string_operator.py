#filename:string_operator.py


text = 'This is a test'
text2 = text+text;text3 = text*3
print("\n",text);print("\n",text2);print("\n",text3)
if text3<text2:
    print("text3 is less than text2")
else:
        print("text3 is greater  than text2")

