import keyword
print(keyword.kwlist)

_salary=60000
print(type(_salary))
_salary=_salary*(1+0.18)
print(type(_salary))
