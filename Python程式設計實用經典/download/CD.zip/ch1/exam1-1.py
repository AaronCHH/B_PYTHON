#filename:exam1-1.py
#function while loop (in chap1)

message_text = 'coap protocol for some IoT projects'
count = 0
max=len(message_text)
while (count < max):
     
    count = count + 1

print ('The char is:', message_text[count])   
print ("vvvvv Good boy vvvvv!")
