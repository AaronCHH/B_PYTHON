#filename:integer.py
f=13.1416
print(int('600'))

print(int(15.02))
print(type(f))
b=int(f)
print("b type=",type(b))
print("b=",b)

print ("Hex = %x,Dec = %d,Oct = %o" %(b,b,b))

