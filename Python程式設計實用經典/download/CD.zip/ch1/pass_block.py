#filename:pass_block.py
#function: the Pause function

brands = ['Apple', 'Samsung', 'IBM', 'Asus']
for br in brands:
   if br =="Samsung":
      pass
      print('this is pass')
   else:   
      print('Brand fan :', br)
