#function :string format
text = 'Justin'
print("text lenth is ",len(text))
for ch in text:
   print("char is %c" %ch)

name = input("Please enter your name: ")
n = input("Please enter an integerof pressure: ")
pressure = int(n)
print ("My name is %s and pressure  is %d !" % (name, pressure))
