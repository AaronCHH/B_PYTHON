text = "\n a string including escaped special character \", \' inside "
print(text)
