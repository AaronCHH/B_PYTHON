#filename:Bool.py
#function : Boolean operators
x = 200
print (x == 200) 
print (x == 100) 

name = "John"
amount = 500
if name == "John" and amount == 500:
    print ("Your name is %s, your amount is %d." %(name,amount))

if name == "John" or name == "Johnny":
    print ("Your name is either John or Johnny.")

