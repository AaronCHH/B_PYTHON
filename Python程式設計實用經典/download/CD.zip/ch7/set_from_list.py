#filename:set_from_list.py
#functio:set creation
#the set will ignore the duplicate item of list 

#set using list and ingone the duplicate item for data analysis
temp_water_pool1 = set([23, 24, 23,22,25,27])
temp_water_pool2 = set([30, 25, 23,24, 29,30])

print("pool1 temperature is:", temp_water_pool1)
print("pool2 temperature is:", temp_water_pool2)

