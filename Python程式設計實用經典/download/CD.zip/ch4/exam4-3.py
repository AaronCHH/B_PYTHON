import random
employee_no=random.randint(0,300)
print(employee_no)
print(random.randint(0,300))
