#filename: chap8_ex2.py
 
ATM={x:x+1 for x in(2,4,6,8)}
print("ATM value is", ATM)
