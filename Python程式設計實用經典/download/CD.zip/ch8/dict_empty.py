
#filename: dict_empty.py
#function: create empty dict using dict()

# Create empty dict
inventory = dict()
print("dictionary data=",inventory)

# Add three key-value tuples to the dictionary.
inventory = {'Murda': 300, 'Coconut': 3000, 'fish': 500}
print("dictionary data=",inventory)

inventory['Women medicine'] = 'from Dr receomend'
print("dictionary data=",inventory)



