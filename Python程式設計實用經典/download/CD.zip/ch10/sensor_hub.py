#filename:sensor_hub.py
#function:The module name is sensor_hub for import by main program
#The module name will not include .py for main program
#This program is for whom want to involve in the IOT field. it is only reference
sensor_degree=[37,38,39]
sec=10
previous_degree=0

def sum_data(a,b):
    print( "\nadding the data from data ",a,b)
    return ((a+b)/2)


