#filename:test_gw.py(in chap10)
#function: test the package function 

from Gateway import sensor_node 
from Gateway import GW_node
testsensor=sensors()
testsensor.printnode()
testGW=GW()
testGW.printGW()
