#filename:__init__.py
#function:Any directory  with an __init__.py file is
#         considered as a Python package.

from sensor_node import sensors
from GW_node import GW
