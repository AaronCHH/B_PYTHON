#filename:fun_for_sensor.py
#function:The module name is fun_for_sensor for import by main program
#The module name will not include .py for main program
#This program is for whom want to involve in the IOT field. it is only reference

def sensor():
    print( "I AM the sensor node id 1210")

node_id=1210
sensor_degree= 32

