[Website](http://doingmathwithpython.github.io) for "Doing Math with Python" - written by [Amit Saha](http://echorand.me), published by [No Starch Press](https://nostarch.com/doingmathwithpython). 
